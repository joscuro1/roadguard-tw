RoadGuard TW v1.0.0
Taiwan speed-camera alerts

This package is the community Android drop from the RoadGuard TW page.
When a signed APK is published, use Download APK on the same page.

Install
1. Return to the RoadGuard TW page and tap Download APK
2. Allow installs from this source on Android
3. Grant location and notification permission
4. Mount the phone on the windshield before you start the drive

Requires Android 8.0+
